#include "i_movie.h"

int I_PlayMovie (const char *movie)
{
	return MOVIE_Failed;
}

